#ifndef _TGW_AllClassDefinitions_h_
#define _TGW_AllClassDefinitions_h_

// #include "TGW_AllClassDefinitions.h"

#include"TGWBitmap.h"
#include"TGWBitmapWindow.h"
#include"TGWButton.h"
#include"TGWCanvas.h"
#include"TGWCheckBox.h"
#include"TGWEdit.h"
#include"TGWindow.h"
#include"TGWMainWindow.h"
#include"TGWTimer.h"
#include"TGWTrackBar.h"

#endif