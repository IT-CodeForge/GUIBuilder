#include "UVector.h"
#include "UVectorElement.h"

UVector::UVector()
{
  first = 0;
  last  = 0;
  size  = 0;
}

UVector::~UVector()
{
  UVectorElement* aktE     = first;
  UVectorElement* toDelete = first;
  for(int i=0; i<size; i++)
  {
     toDelete = aktE;
     aktE = aktE->next;
     delete toDelete;
  }

  size=0;
  first = 0;
  last = 0;
}

void UVector::clear()
{
  UVectorElement* aktE    = first;
  UVectorElement* deleteE = first;
  for(int i=0; i<size; i++)
  {
     deleteE = aktE;
     aktE = aktE->next;

     deleteContentOfElement(deleteE);
     delete deleteE; deleteE=0;
  }

  first = 0;
  last  = 0;
  size  = 0;
}

void UVector::deleteAllContentOfElements()
{
  UVectorElement* aktE = first;
  for(int i=0; i<size; i++)
  {
     deleteContentOfElement(aktE);
     aktE = aktE->next;
  }
}

int UVector::erase(int pos)          // Rest wird nach links einger�ckt. Wenn
{                                    // i >= size() wird der Befehl ignoriert.
  UVectorElement* e = getAt(pos);    // Returns size.

  if(e==0) return size;

  if(e->previous != 0)
    e->previous->next = e->next;
  else
    first = e->next;

  if(e->next != 0)
    e->next->previous = e->previous;
  else
    last = e->previous;

  deleteContentOfElement(e);
  delete e;
  size--;
  return size;
}

UString UVector::toString()
{
  UString retVal("UVector:");
  retVal = retVal + "\nthis=";
  retVal.addPointer(this);
  retVal = retVal + "\nfirst=";
  retVal.addPointer(first);
  retVal = retVal + "\nlast=";
  retVal.addPointer(last);
  retVal = retVal + "\nsize=" + size;

  UVectorElement* aktE = first;
  for(int i=0; i<size; i++)
  {
    retVal = retVal + "\n[" + i + "]:" + aktE->toString() + "\n";
    aktE = aktE->next;
  }

  return retVal;
}

int UVector::insertAt(int pos, void* content)
{
  if(pos >= size) return -1;

  UVectorElement* e = new UVectorElement();
  e->content = content;
  UVectorElement* eNext = getAt(pos);

  e->next = eNext;
  e->previous = eNext->previous;

  if(e->previous != 0)
    e->previous->next = e;
  else
    first = e;

  e->next->previous = e;

  size++;
  return size;
}

UVectorElement* UVector::getAt(int pos) // Returns 0 if not existing
{
  if (pos >= size) return 0;

  UVectorElement* aktE = first;
  for(int i=0; i<pos; i++)
  {
    aktE=aktE->next;
  }
  return aktE;
}

int UVector::push_back(void* content) //Returns new size
{
  if(last==0)
  {
    first = last = new UVectorElement();
    first->content = content;
  }
  else
  {
    last->next = new UVectorElement();
    last->next->previous = last;
    last = last->next;

    last->content = content;
  }
  size++;
  return size;
}

UVectorElement* UVector::getNext()
{
  if(aktE == 0) return 0;

  UVectorElement* retE = aktE;
  aktE = aktE->next;
  return retE;
};

