#ifndef _FileLogDevice_h
#define _FileLogDevice_h

#include "LogDevice.h"
#include "UString.h"

class FileLogDevice : public LogDevice
{
private:
  UString fileName;

public:
  FileLogDevice(UString fileName);
public:
  ~FileLogDevice();

public:
  void     out(UString toLog);
};


#endif
