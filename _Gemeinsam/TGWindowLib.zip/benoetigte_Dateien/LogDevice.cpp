#include "LogDevice.h"

LogDevice::LogDevice(void)
{
}

LogDevice::~LogDevice(void)
{
}
