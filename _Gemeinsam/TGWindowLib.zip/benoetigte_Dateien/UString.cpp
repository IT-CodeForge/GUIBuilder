#include "UString.h"
#include <string.h>
#include <math.h>
#include <stdio.h>

int UString::n=0;

UStringMem::UStringMem()
{
  m_create("", STANDARD_ALLOCATION_INCREMENT);
}

UStringMem::UStringMem(int filledLengt, char fillChar)
{
  m_create("", STANDARD_ALLOCATION_INCREMENT+filledLengt);

  for(int i=0; i<filledLengt; i++)
  {
    m_text[i]=fillChar;
  }
  m_text[filledLengt]=0;

  m_textStrLen = filledLengt;
}

UStringMem::UStringMem(const UStringMem& s)
{
  if(&s == this) return;
  m_create(s.m_text, STANDARD_ALLOCATION_INCREMENT);
}

UStringMem::UStringMem(const char* s)
{
  m_create(s, STANDARD_ALLOCATION_INCREMENT);
}

UStringMem::~UStringMem()
{
  m_delete();
}

void UStringMem::m_setTo(char const* s, int calculatesStrLen)
{
  if (s == 0) s = "";
  if (calculatesStrLen == -1) calculatesStrLen = strlen(s);

  m_textStrLen = calculatesStrLen;

  if (m_textStrLen >= m_textBytesAllokiert)
  {
    delete[] m_text;
    m_textBytesAllokiert = m_textStrLen + m_allocationIncrement;
    m_text = new char[m_textBytesAllokiert];
  }

  strcpy(m_text, s);
}

void UStringMem::m_setMinimumBufferSize(int size, bool keepText)
{
  if (m_textBytesAllokiert >= size) return;
  if (size < 1) size = 1;

  if (keepText == false)
  {
    delete m_text;
    m_text = new char[size];
    m_text[0] = 0;
    m_textBytesAllokiert = size;
    m_textStrLen = 0;
  }
  else
  {
    m_textBytesAllokiert = size;
    char* s = new char[m_textBytesAllokiert];
    strcpy(s, m_text);
    delete[] m_text;
    m_text = s;
  }
}

void UStringMem::m_delete()
{
  delete[] m_text;
  m_text               = 0;
  m_textStrLen         = 0;
  m_textBytesAllokiert = 0;
}

void UStringMem::m_create(const char* s, int allocationIncrement)
{
  this->m_allocationIncrement = allocationIncrement;

  if (s == 0)
  {
    s = "";
  }

  m_textStrLen = strlen(s);
  m_textBytesAllokiert = m_textStrLen + allocationIncrement;
  m_text = new char[m_textBytesAllokiert];
  strcpy(m_text, s);
}

const char* UStringMem::c_str()
{
  return m_text;
}

void UStringMem::setAt(int pos, char c) // pos must be 0 .. length()-1
{
  if(pos < 0) return;
  if(pos >= m_textStrLen) return;
  m_text[pos]=c;
}

void UStringMem::m_add(const char* s, int countOfCharsToCopy)
{
  m_setMinimumBufferSize(m_textStrLen + countOfCharsToCopy + 1, true);
  memcpy(m_text + m_textStrLen, s, countOfCharsToCopy); //countOfCharsToCopy wird kopiert, NICHT strlen(s); Wichtig wegen Kopie von Teilstrings!
  m_textStrLen += countOfCharsToCopy;
  m_text[m_textStrLen]=0; // Stringende
}

//////////////////////////////////////////////////////////////////////////

UString::UString()
  :UStringMem()
{
  n++;
}

UString::UString(int length, char fillChar)
  :UStringMem(length, fillChar)
{
  n++;
}

UString::UString(const UString& s)
  :UStringMem(s)
{
  n++;
}

UString::UString(const char* s)
  :UStringMem(s)
{
  n++;
}

UString::UString(double d)
  :UStringMem((char*)"")
{
  n++;
  if( ((int)d) == d)
  {
    *this += (int)d;   // BUG? Evtl int-Konstruktor?
  }
  else
  {
    addDouble(d);
  }
}

UString::~UString()
{
  n--;
}


void UString::setMinimumBufferSize(int size, bool keepText)
{
  m_setMinimumBufferSize(size, keepText);
}

UString& UString::operator=(const char* s)
{
  m_setTo(s, -1);  // No precalculatedStrlenAvailable
  return *this;
}

UString& UString::operator=(const UString& s)
{
  if(&s == this) return *this;

  UString* u = (UString*)&s;
  const char* c = u->c_str();
  m_setTo(c, u->length());
  return *this;
}

UString UString::operator+(const char s)
{
  UString erg;
  erg = *this;
  erg.addText(&s, 1);
  return erg;
}

UString UString::operator+(const char* s)
{
  UString erg;
  erg = *this;
  erg.m_add(s, strlen(s));
  return erg;
}

UString UString::operator+(const UString& s)
{
  UString* u = (UString*)&s;
  UString erg;
  erg = *this;
  erg.m_add(u->c_str(), u->length());
  return erg;
}

UString& UString::operator+=(const UString& s)
{
  UString* u = (UString*)&s;
  m_add(u->c_str(), u->length());
  return *this;
}

UString& UString::operator+=(const char* s)
{
  m_add(s, strlen(s));
  return *this;
}

UString& UString::operator+=(char const s)
{
  m_add(&s, 1);
  return *this;
}

int UString::toInt(bool* isValid)
{
  bool valid = true;
  if (length()==0)
  {
    valid=false;
    return 0;
  }

  const char* s = c_str();
  int sign=1;
  if(*s == '-')
  {
    sign = -1;
    s++;
  }

  int num=0;
  char c;
  while(*s)
  {
    c = *s;
    if (c=='.') break;

    num=charToNumerical(c, &valid)+num*10;
    if(valid == false) break;
    s++;
  }

  num*=sign;

  if (valid==false)
  {
    num = 0;
  }

  if (isValid != 0)
  {
    *isValid = valid;
  }

  return num;
}

UString UString::replace(UString searchPattern, UString replacement)
{
  UString temp = *this;
  int pos = temp.find(searchPattern);
  int spl = searchPattern.length();
  int rpl = replacement.length();

  while (pos != -1)
  {
    temp = temp.subString(0,pos) + replacement +  temp.subString(pos+spl);
    pos = temp.find(searchPattern, pos+rpl);
  }

  return temp;
}

int UString::countSubstring(UString s)
{
  int startIndex = 0;
  int anzahlGefunden = 0;

  int gef = find(s, startIndex);
  while (gef > -1)
  {
    anzahlGefunden++;
    startIndex = gef+1;
    gef = find(s, startIndex);
  }

  return anzahlGefunden;
}

int UString::countSubstring(char* s)
{
  UString u(s);
  return countSubstring(u);
};

int UString::find(char c, int startIndex)
{
  char cs[2]={0,0};
  cs[0]=c;
  return find(cs);
}

int UString::find(UString s, int startIndex)
{
  if(s=="") return -1;

  bool alleBuchstabenGleich;
  for (int i = startIndex; i<length(); i++)
  {
    alleBuchstabenGleich = true;
    for(int k=0; k<s.length(); k++)
    {
      char c1 = (*this)[i+k];
      char c2 = s[k];
      if (c1 != c2)
      {
        alleBuchstabenGleich = false;
        break;
      }
    }

    if (alleBuchstabenGleich) // Alle waren gleich --> kein break
    {
      return i;  // gefunden!
    }
  }

  return -1; // nix gefunden
}

UString UString::subString(int index, int count)
{
  if (length() < index) return UString((char*)"");
  if (count == 0) return UString((char*)"");

  UString erg;
  erg = this->c_str()+index;

  if (count < 0) return erg; // Nur den Anfang beschneiden

  if (erg.length() > count)    // Wenn mehr Zeichen da sind als count angibt
  {
    *((char*)erg.c_str()+count) = 0; // Stringende setzen
  }

  return erg;
}

UString UString::operator+(const double zahl)
{
  UString plus;
  plus = plus.addDouble(zahl, 20);
  return this->operator+(plus);
}

UString UString::operator+(const int zahl)
{
  char buffer_100[100];
  sprintf(buffer_100, "%i", zahl);
  return this->operator+(buffer_100);
}

bool UString::operator==(UString einText)
{
  return *this==einText.c_str();
}

bool UString::operator==(const char* einText)
{
  if (einText == 0) return false;
  return ( strcmp(einText, c_str()) == 0 );
}

bool UString::operator<(UString &einText)
{
  return strcmp(c_str(), einText.c_str())<0;
}

bool UString::operator>(UString &einText)
{
  return strcmp(einText.c_str(), c_str())<0;
}

void UString::writeToFile(UString filename)
{
  FILE* file= fopen(filename.c_str(), "w");
  if (file == 0) return;
  fwrite(c_str(), length(), 1, file);
  fclose(file);
}

UString& UString::addText(const char* einText, int einTextStrlength)
{
  if (einTextStrlength == -1) einTextStrlength = strlen(einText);
  m_add(einText, einTextStrlength);
  return *this;
}

UString& UString::addPointer(void* einPointer)
{
  int value;
  #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wstrict-aliasing"
    value = *( (int*)&einPointer );
  #pragma GCC diagnostic pop

  *this = this->operator+(value);
  return *this;
}

// static
unsigned int UString::charToNumerical(char c, bool* valid)
{
   unsigned int uc = (unsigned int)(c-'0');

   *valid = (uc < 10);

   if (*valid)
     return uc;
   else
     return 0;
}

bool UString::readFromFile(UString filename)
{
  FILE* file= fopen(filename.c_str(), "rb");
  if (file == 0) return false;

  fseek(file, 0L, SEEK_END);
  int size = ftell(file);
  rewind(file);

  char* buffer = new char[size+1];
  int anzBytes = fread(buffer, 1, size, file);
  buffer[anzBytes] = 0;

  fclose(file);

  *this = buffer;

  delete[] buffer;

  *this = this->replace("\r\n","\n");

  return true;
}

UString UString::trimSpaces(int left0_right1_both2)
{
  int len=length();
  if (len==0)                                  return *this;
  if ((c_str()[0]!=' ')&&(c_str()[len-1]!=' ')) return *this;

  int index[2];

  // Linke Seite suchen
  index[0]=len;
  for (int i=0; i<len; i++)
  {
    if(c_str()[i] != ' ')
    {
      index[0] = i;
      break;
    }
  }

  if(index[0] == len) // nur Leerzeichen
  {
    return "";
  }

  // Rechte Seite suchen
  for (int i=length()-1; i>=0; i--)
  {
    if(c_str()[i] != ' ')
    {
      index[1] = i;
      break;
    }
  }

  return subString(index[0], index[1]-index[0]+1);  // pos, count
}

UString UString::trimLength(int forcedLength, char fillChar, bool fillOrTrimFromRightSide)
{
  int l=length();
  if (forcedLength == l) return *this;

  if (forcedLength < l)
  {
    if (fillOrTrimFromRightSide == true)
    {
      return this->subString(l-forcedLength);
    }
    else
    {
      return this->subString(0, forcedLength);
    }
  }
  else
  {
    int delta = forcedLength - l;
    UString s(delta, fillChar);
    if (fillOrTrimFromRightSide == true)
    {
      return *this + s;
    }
    else
    {
      return s + *this;
    }
  }
}

UString UString::toUpperCase()
{
  UString s(*this);
  int diff = 'A' -'a';

  char c;
  for(int i=0; i<s.length(); i++)
  {
    c = s[i];
    if( ('a'<=c) && (c<='z'))
    {
      s.setAt(i, c+diff);
    }
    else if(c==132) s.setAt(i, 142); //ae
    else if(c==148) s.setAt(i, 153); //oe
    else if(c==129) s.setAt(i, 154); //ue
  }
  return s;
}

double UString::toDouble(bool* isValid)
{
  bool v = false;
  if(isValid==0) isValid = &v;

  UString doubleString = *this;
  doubleString = doubleString.trimSpaces(2); // left+right

  if (doubleString.length()==0)
  {
    *isValid = false;
    return 0;
  }

  int anzahlKommas;
  UString p((char*)".");
  UString n((char*)"");
  UString k((char*)",");

  anzahlKommas = doubleString.countSubstring(k);
  if (anzahlKommas > 1)
  {
    *isValid = false;
    return 0;
  }
  else if (anzahlKommas == 1)
  {
    doubleString = doubleString.replace(p, n);
    doubleString = doubleString.replace(k, p);
  }
  else
  {
    int anzahlPunkte = doubleString.countSubstring(p);
    if (anzahlPunkte > 1)
    {
      doubleString = doubleString.replace(p, n);
    }
  }

  // ab hier:  12.3400 oder 0120 oder -0120.0340 oder -12

  if (doubleString.countSubstring(p) == 0)
  {
    return doubleString.toInt(isValid);  // Keine Nachkommastellen
  }

  // ab hier:  0120.0340 oder -0120.0340

  int sig = doubleString[0]=='-'?-1:1;
  if (sig == -1)
  {
     doubleString = doubleString.subString(1);
  }

  // ab hier:  0120.0340

  int posKomma = doubleString.find(p);
  if(posKomma == 0) // Keine anführende Null
  {
    doubleString = UString("0") + doubleString.subString(0, posKomma) + doubleString.subString(posKomma+1, -1);
  }
  else
  {
    doubleString = doubleString.subString(0, posKomma) + doubleString.subString(posKomma+1, -1);
    posKomma--;
  }

  double dErg     = 0;
  double potenz   = pow(10, posKomma);
  int length      = doubleString.length();
  char ziffer   = '0';
  for(int i=0; i<length; i++)
  {
    ziffer = doubleString[i];
    if(ziffer != '0')
    {
      dErg += charToNumerical(ziffer, isValid) * potenz;
      if(*isValid==false) return 0; // Keine gueltige Ziffer
    }

    if(i>11+posKomma) break;
    potenz/=10;
  }
  
  return dErg*sig;  // Letzte Ziffer ist falsch (Rundungsfehler) .. OK
}

UString& UString::addChar(char c)
{
  char str[2]={0};
  str[0] = c;
  *this = *this + str;
  return *this;
}

UString& UString::addDouble(double d, int anzahlNachkommastellen, int anzahlVorkommastellen, char kommaZeichen)
{
  int maxVorNachkommaNullen = 16; 
  if(anzahlNachkommastellen==-1) anzahlNachkommastellen = maxVorNachkommaNullen;
  if(anzahlVorkommastellen ==-1) anzahlVorkommastellen  = maxVorNachkommaNullen;

  int sizeErg = 2*maxVorNachkommaNullen+3; // +3 wegen Komma, Minus und abschliessende 0
  char* erg = new char[sizeErg]; 
  for(int i=0; i<sizeErg; i++) erg[i]='0';
  erg[sizeErg-1] = 0;
  int kommaPos = maxVorNachkommaNullen+1;
  erg[kommaPos] = kommaZeichen; //"-0000,0000NULL"

  int sig = d>0?1:-1;
  if(sig<0)d=-d;

  if(anzahlVorkommastellen<1)anzahlVorkommastellen=1;
  if(anzahlVorkommastellen>maxVorNachkommaNullen)anzahlVorkommastellen=maxVorNachkommaNullen;
  if(anzahlNachkommastellen>16)anzahlNachkommastellen=16; // Doubles haben max 16 gueltige Nachkommastellen

  int addMinus = 0;
  if(d>0) 
  {
    int ziffer = 0;
    int vorkommaPotenz = log10(d);
    if(anzahlVorkommastellen<vorkommaPotenz+1)anzahlVorkommastellen=vorkommaPotenz+1;
    
    double potenz = pow(10, vorkommaPotenz);
    double dZehn = 10;

    int writepos = kommaPos-vorkommaPotenz-1;

    do
    {
      if(erg[writepos]==kommaZeichen) writepos++;
      ziffer = d/potenz;
      d = d - (double)ziffer*potenz;
      potenz/=dZehn;
      erg[writepos]=ziffer+'0';
      writepos++;
    } 
    while (writepos<kommaPos+anzahlNachkommastellen);  

    if(sig<0)
    { 
      addMinus = 1;
      erg[kommaPos-anzahlVorkommastellen-1] = '-';
    } 
  }

  if(anzahlNachkommastellen == 0) anzahlNachkommastellen = -1; //Wegen Komma
  erg[kommaPos+anzahlNachkommastellen+1] = 0;  

  *this += UString(erg+kommaPos-anzahlVorkommastellen-addMinus);

  delete[] erg;
  
  return *this;
}
