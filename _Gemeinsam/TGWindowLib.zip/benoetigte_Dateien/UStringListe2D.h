#ifndef _UStringListe2D_h_
#define _UStringListe2D_h_

#include "UString.h"
class UStringListe;
/*
Diese Liste �bernimmt den Besitz ihrer Elemente (das sind UStringlisten*).
Das bedeutet: Alle Zeilen werden beim anlegen instanziert
und mit dem Destruktor dieser Liste wieder aus dem Speicher gel�scht.
Es gibt keine NULL-Zeiger, das bedeutet JEDES Zeile existiert
mindestens als Leere UStringListe.

Der Index i l�uft von oben nach unten, das Bedeutet:                row row row row
0 ... Erste Stringliste (=Zeile)                                col
1 ... Zweite Zeile                                              col
2 ...                                                           col
                                                                col
Alle Zeilen haben immer gleich viele Elemente.                  col
Beim Einf�gen bestimmter Positionen werden entsprechend
ganze Spalten  mit Leerstrings eingef�gt.

*/
class UStringListe2D
{
private:
  void* dieVectorListe;
  int _width;
  int _height;

  UStringListe* createNewLine();   // Erzeugt neue Zeile mit vorgefertigter L�nge von _width
  UStringListe* at(int y);         // Liefert die Reihe, fall diese Existiert, sonst Null

public:
  UStringListe2D();
  UStringListe2D(UStringListe2D & kopierkonstruktor){throw "Copy not allowed";};
  UStringListe2D& operator=(UStringListe2D & s){throw "Copy not allowed";};
  virtual ~UStringListe2D();
  void copyFrom(UStringListe2D & s);

  // alle insertRow/Col sorgen f�r
  // eine korrekte L�nge der neuen Zeile
  void insertRow(int y, UStringListe* s = 0); // Reihe an der Stelle Y wird nach unten weggeschoben.
  // Wenn y > height() dann wird mit leerzeilen aufgef�llt.
  void insertCol(int x);  // Entsprechend insertRow()

  void deleteRow(int y);           // Reihen unterhalb von y werden nach oben verschoben.
  // Wenn y > height() dann wird der Befehl nicht ausgef�hrt.
  void deleteCol(int x);           // Entsprechend deleteRow()

  void swapRow(int y1, int y2);// Tauscht zwei Zeilen

  inline int width()
  {
    return _width;
  };
  inline int height()
  {
    return _height;
  };

  UString getAt(int x, int y );   // Liefert E(x,y). Falls x > width oder
  // y > height, dann liefert der Befehl
  // einen Leerstring.

  void     setAt(int x, int y, UString r); // E(x,y), wird mit r �berschrieben.
  // Falls x oder y gr�sser als width oder
  // height, wird mit Leerstrings / Leerzeilen
  // aufgef�llt.

  void clear();                    // Gesamte Listeninhalte l�schen.
  // width und height ist danach 0.

  UString toString();             // Zu Debugzwecken
};

#endif


