#ifndef _UString_h_
#define _UString_h_

///////////////////////////////////////
// ...Universal String:
// Laeuft unter GCC, Borland und Arduino
///////////////////////////////////////

#define STANDARD_ALLOCATION_INCREMENT 2

/*
Referenzen:
   http://stackoverflow.com/questions/5973427/error-passing-xxx-as-this-argument-of-xxx-discards-qualifiers

   http://www.stroustrup.com/bs_faq2.html#whitespace
    Note that in const pointers, "const" always comes after the "*". For example:
	  int *const p1 = q;	// constant pointer to int variable
	  int const* p2 = q;	// pointer to constant int
	  const int* p3 = q;	// pointer to constant int

*/

class UStringMem
{
protected:
  // Diese Attribute duerfen nur von m_XXXX Methoden veraendert werden

private:
  // Diese Attribute duerfen nur von m_XXXX Methoden veraendert werden
  char* m_text;
  int   m_textStrLen; // "Hello" has strLen = 5
  int   m_textBytesAllokiert;
  int   m_allocationIncrement;

public:
  int length()
  {
    return m_textStrLen;
  };
  UStringMem();
  UStringMem(int filledLengt, char fillChar);
  UStringMem(const UStringMem& s);
  UStringMem(const char* s);
  virtual ~UStringMem();

  // Nur m_XXX-Methoden, UStringMem-Konstruktoren und ~UStringMem() duerfen
  // m_XXX-Attribute, new oder delete verwenden!
  void        m_delete();
  void        m_create(const char* s, int allocationIncrement);
  void        m_setMinimumBufferSize(int size, bool keepText);
  void        m_setTo(const char* s, int calculatedStrLen);
  void        m_add(const char* s, int countOfCharsToCopy);
  void        setAt(int pos, char c); // pos must be 0 .. length()-1
 
  char& operator[](int index)
  {
    if(index>length() || index<0) throw "UStringMem index violation";
    return *(m_text+index);
  };

  const char* c_str();
};

class UString : public UStringMem
{
  static int n;

public:
  UString();
  UString(int length, char fillChar);
  UString(const UString& s);
  UString(const char* s);
  UString(double d);
  virtual ~UString();

  void setMinimumBufferSize(int size, bool keepText);

  static unsigned int charToNumerical(char c, bool* valid);

  UString& operator=(const UString & s);
  UString& operator=(const char* s);
  UString& operator=(const char s)
  {
    return operator=(UString()+s);
  };
  UString& operator=(double zahl)
  {
    return operator=(UString()+zahl);
  };
  UString& operator=(int zahl)
  {
    return operator=(UString()+zahl);
  };


  UString& operator+=(const UString & s);
  UString& operator+=(char const* s);
  UString& operator+=(char const s);
  UString& operator+=(double zahl)
  {
    return operator+=(UString()+zahl);
  }
  UString& operator+=(int zahl)
  {
    return operator+=(UString()+zahl);
  }

  UString operator+(const UString& s);
  UString operator+(const char* s);
  UString operator+(const char  s);
  UString operator+(const double zahl);
  UString operator+(const int zahl);

  bool operator>(UString &einText);
  bool operator<(UString &einText);

  bool operator==(UString einText);
  bool operator==(const char* einText);
  bool operator!=(UString einText)    {return !operator==(einText);};
  bool operator!=(const char* einText){return !operator==(einText);};

  int      toInt(bool* isValid=0);
  double   toDouble(bool* isValid = 0);
  UString  replace(UString search, UString replacement);// replaces all all matches in replacement
  int      countSubstring(char* s);
  int      countSubstring(UString s);
  int      find(UString s, int startIndex=0);  // returns -1 if not found    abcde.find("cd") returns 2;
  int      find(char    c, int startIndex=0);  // returns -1 if not found    abcde.find('c') returns 2;
  UString  subString(int index, int count=-1); // returns index to end if count < 0: abcd.substring(1, -42) => bcd 

  UString& addDouble(double d, int anzahlNachkommastellen=-1, int anzahlVorkommastellen=0, char kommaZeichen=',');
  UString& addText(const char* einText, int einTextStrlength = -1);
  UString& addChar(char c);

  inline UString & addText(UString s)
  {
    addText(s.c_str(), s.length());
    return *this;
  };
  UString& addPointer(void* einPointer);
  UString  trimSpaces(int left0_right1_both2 = 2);
  UString  trimLength(int forcedLength, char fillChar, bool fillOrTrimFromRightSide);
  UString  toUpperCase();

  bool readFromFile(UString filename);
  void writeToFile(UString filename);
};

#endif
