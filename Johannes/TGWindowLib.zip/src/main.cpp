#include "GUI.h"
#include <iostream>


//https://docs.microsoft.com/en-us/windows/desktop/learnwin32/creating-a-window
//https://msdn.microsoft.com/de-de/library/windows/desktop/ms633559(v=vs.85).aspx
int WINAPI WinMain(HINSTANCE hApplication, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int nCmdShow)
{
  GUI* mainWindow = new GUI();

  int exitCode;
  try
  {
               // Blocking call until exit:
    exitCode = mainWindow->run(hApplication, nCmdShow);
  }
  catch(char const* txt)
  {
    std::cout << txt;
  }
  catch(...)
  {
    std::cout << "Unknown Exception";
  }
  delete mainWindow;
  return exitCode;
}
