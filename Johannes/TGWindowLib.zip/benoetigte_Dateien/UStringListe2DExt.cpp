#include "UStringListe2DExt.h"
#include "UStringListe.h"

void UStringListe2DExt::swapCol(int x1, int x2)
{
  if ((x1>=width())||(x2>=width())) return;

  UString merk;
  for (int y = 0; y<height(); y++)
  {
    merk = getAt(x1, y);
    setAt(x1, y, getAt(x2, y));
    setAt(x2, y, merk);
  }
}

void UStringListe2DExt::copyRowToRow(int sourceY, int targetY, int firstX, int lastX)
{
  if ((sourceY >= height())||(targetY >= height())) return;

  if (firstX == -1) firstX = 0;
  if (lastX  == -1) lastX  = width()-1;

  if (firstX > lastX) return;
  if (lastX >= width()) return;

  for (int x = firstX; x<lastX; x++)
  {
    setAt(x, targetY,  getAt(x, sourceY));
  }
}

void UStringListe2DExt::copyColToCol(int sourceX, int targetX, int firstY, int lastY)
{
  if ((sourceX >= width())||(targetX >= width())) return;

  if (firstY == -1) firstY = 0;
  if (lastY  == -1) lastY  = height()-1;

  if (firstY > lastY) return;
  if (lastY >= height()) return;

  for (int y = firstY; y<lastY; y++)
  {
    setAt(targetX, y, getAt(sourceX, y));
  }
}


void UStringListe2DExt::trimElementsInRow(int y)
{
  if (y>=height()) return;
  for (int x=0; x<width(); x++)
  {
    setAt(x,y, getAt(x,y).trimSpaces());
  }
}

int UStringListe2DExt::countElementsInRow(int y)
{
  int erg = 0;
  if (y>=height()) return 0;
  for (int x=0; x<width(); x++)
  {
    if(getAt(x,y) != "") erg++;
  }
  return erg;
}

void UStringListe2DExt::trimElementsInCol(int x)
{
  if (x>=width()) return;
  for (int y=0; y<height(); y++)
  {
    setAt(x,y, getAt(x,y).trimSpaces());
  }
}

int UStringListe2DExt::countElementsInCol(int x)
{
  int erg = 0;
  if (x>=width()) return 0;
  for (int y=0; y<height(); y++)
  {
    if(getAt(x,y) != "") erg++;
  }
  return erg;
}

void UStringListe2DExt::trimElements()
{
  for (int y=0; y<height(); y++)
  {
    trimElementsInRow(y);
  }
}

int UStringListe2DExt::searchRelatedY(int x, UString searchString, int startY)
{
  if (startY > height()-1) return -1;

  for (int y=startY; y<height(); y++)
  {
    UString s = getAt(x,y);
    if ( s == searchString )
      return y;
//    if (getAt(x,y)==searchString) return y;
  }

  return -1;
}

int UStringListe2DExt::searchRelatedX(int y, UString searchString, int startX)
{
  if (startX > width()-1) return -1;

  for (int x=startX; x<width(); x++)
  {
    if (getAt(x,y)==searchString) return x;
  }

  return -1;
}

// Collumn = Spate
// Gesamte Tabelle nach dem Inhalt der Spalte[x] sortieren. (SwapRow wird verwendet)
void UStringListe2DExt::sortCol(int x, bool numericNotAnsi, int firstY, int lastY, bool aufsteigend)
{
  if (height() < 2) return;
  if (lastY==-1) lastY = height()-1;

  if (numericNotAnsi)
  {
    int a;               // SortierterBereich[nicht sortiert]
    int b;               //                 a        b

    bool isValid;
    for (int ya = firstY; ya<lastY; ya++)
    {
      a = getAtInt(x, ya, &isValid); // Erster Wert
      if (!isValid) continue;
      for (int yb = ya+1; yb<lastY+1; yb++)
      {
        b = getAtInt(x, yb, &isValid); // Zweiter Wert
        if (!isValid) continue;

        if( (a>b)==aufsteigend )
        {
          swapRow(ya, yb);
          a = b;  // Neuer a-Wert ist jetzt b
        }
      }
    }
  }
  else
  {
    UString a;
    UString b;

    for (int ya = firstY; ya<lastY; ya++)
    {
      a = getAt(x, ya); // Erster Wert
      for (int yb = ya+1; yb<lastY+1; yb++)
      {
        b = getAt(x, yb); // Zweiter Wert

        if( (a > b) == aufsteigend )
        {
          swapRow(ya, yb);
          a = b;  // Neuer a-Wert ist jetzt b
        }
      }
    }
  }
}

// Row = Zeile
// Gesamte Tabelle nach dem Inhalt der Zeile[y] sortieren. (SwapCol wird verwendet)
void UStringListe2DExt::sortRow(int y, bool numericNotAnsi, int firstX, int lastX, bool aufsteigend)
{
  if (width() < 2) return;
  if (lastX==-1) lastX = width()-1;

  if (numericNotAnsi)
  {
    int a;               // SortierterBereich[nicht sortiert]
    int b;               //                 a        b

    bool isValid;
    for (int xa = firstX; xa<lastX; xa++)
    {
      a = getAtInt(xa, y, &isValid); // Erster Wert
      if (!isValid) continue;
      for (int xb = xa+1; xb<lastX+1; xb++)
      {
        b = getAtInt(xb, y, &isValid); // Zweiter Wert
        if (!isValid) continue;

        if( (a<b)==aufsteigend )
        {
          swapCol(xa, xb);
          a = b;  // Neuer a-Wert ist jetzt b
        }
      }
    }
  }
  else
  {
    UString a;
    UString b;

    for (int xa = firstX; xa<lastX; xa++)
    {
      a = getAt(xa, y); // Erster Wert
      for (int xb = xa+1; xb<lastX+1; xb++)
      {
        b = getAt(xb, y); // Zweiter Wert

        if( (a<b)==aufsteigend )
        {
          swapCol(xa, xb);
          a = b;  // Neuer a-Wert ist jetzt b
        }
      }
    }
  }
}

void UStringListe2DExt::init(UStringListe2D* quellDaten)
{
  for (int y=0; y<quellDaten->height(); y++)
  {
    for (int x=0; x<quellDaten->width(); x++)
    {
      setAt(x,y,quellDaten->getAt(x,y));
    }
  }
}

void UStringListe2DExt::writeToFile (UString filename, UString itemSeparator, UString lineSeparator)
{
  UString dateiInhalt;
  for(int y=0; y<height(); y++)
  {
    for (int x=0; x<width(); x++)
    {
      dateiInhalt += getAt(x,y);

      if (x<width()-1)
      {
        dateiInhalt += itemSeparator;
      }

    }
    dateiInhalt += lineSeparator;
  }

  dateiInhalt.writeToFile(filename);
}

bool UStringListe2DExt::readFromFile(UString filename, UString itemSeparator, UString lineSeparator, unsigned char* ignoreList, int ignoreListSize)
{
  UString dateiInhalt;

  bool result = dateiInhalt.readFromFile(filename);
  if (result == false)
    return false;
  if (dateiInhalt.length() == 0)
    return false;

  int index=0;
  UString wort;
  int x = 0;
  int y = 0;
  while (index < dateiInhalt.length())
  {
    char c = dateiInhalt[index];
    index++;

    int i;
    for(i=0; i<ignoreListSize; i++)
    {
      if(c==ignoreList[i]) break;
    }

    if (i!=ignoreListSize) continue;

    if (c == itemSeparator[0])
    {
      setAt(x,y,wort);
      wort = "";
      x++;
    }
    else if (c == lineSeparator[0])
    {
      setAt(x,y,wort);
      wort = "";
      y++;
      x = 0;
    }
    else
    {
      wort += c;
    }
  }

  return true;
}

int UStringListe2DExt::getAtInt(int x, int y, bool* isValid)
{
  return getAt(x,y).toInt(isValid);
}

double UStringListe2DExt::getAtDouble(int x, int y, bool* isValid)
{
  UString debug = getAt(x,y);
  return getAt(x,y).toDouble(isValid);
}

/*
int UStringListe2DExt::getAtDDMMYYYY(int x, int y, bool* isValid )
{
   return getAt(x,y).getDayOfDateDDMMYYYY(isValid);
}

void UStringListe2DExt::setAtDDMMYYYY(int x, int y, int day)
{
   UString DDMMYYYY;
   DDMMYYYY.setDateOfDayDDMMYYYY(day);
   setAt(x,y, DDMMYYYY);
}
*/

void UStringListe2DExt::setAtDouble(int x, int y, double w, int nachkommastellen)
{
  UString s;
  s.addDouble(w, nachkommastellen);
  setAt(x,y, s);
}

