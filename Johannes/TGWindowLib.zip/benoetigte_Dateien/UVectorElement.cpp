#include "UVectorElement.h"

UVectorElement::UVectorElement()
{
  next     = 0;
  previous = 0;
  content  = 0;
}

UVectorElement::~UVectorElement()
{
  if( content != 0 ); // throw "Delete in derivated Class first! Use: UVector::deleteContentOfElement(..)";
}

UString UVectorElement::toString()
{
  UString retVal;
  retVal = retVal + "\nthis=";
  retVal.addPointer(this);

  retVal = retVal + "\nnext=";
  retVal.addPointer(next);

  retVal = retVal + "\nprevious=";
  retVal.addPointer(previous);

  retVal = retVal + "\ncontent=";
  retVal.addPointer(content);

  return retVal;
}