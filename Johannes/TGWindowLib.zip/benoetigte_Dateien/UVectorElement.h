#ifndef _UVectorElement_h_
#define _UVectorElement_h_

#include "UString.h"

class UVector;
class UVectorElement
{
  friend UVector;

protected:
  UVectorElement* next;
  UVectorElement* previous;
public:
  void* content;
  UVectorElement();
  virtual ~UVectorElement();
  UString toString();
};

#endif