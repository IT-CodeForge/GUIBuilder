#include "FileLogDevice.h"
#include <stdio.h>
#include "Log.h"
#include "UString.h"
#include <windows.h>

FileLogDevice::FileLogDevice(UString fileName)
{
  this->fileName = fileName;

  // anlegen und testen
  FILE*  pFile = 0;
  try
  {
    pFile = fopen(fileName.c_str(), "w");
  }
  catch(...)
  {
    return;
  }
  
  if (pFile==0) return;
  fclose(pFile);
}

void FileLogDevice::out(UString text)
{
  FILE* pFile;
  pFile=fopen(fileName.c_str(), "a");
  if (pFile==0) return;
  fprintf(pFile,"%s \n", text.c_str());
  fclose (pFile);


  if(text[0] == '[')
  {
    int pos2 = text.find("]");
    if (pos2 < 15)
    {
      UString procID_Filename;
      UString fn(fileName);
      if(fileName[1] == ':')
      {
        procID_Filename =
            fn.subString(0,3)
          + text.subString(1,pos2-1)
          + fn.subString(3);
      }
      else
      {
        procID_Filename =
            text.subString(1,pos2-1)
          + fn;
      }

      FILE* pFile;
      pFile=fopen(procID_Filename.c_str(),"a");
      fprintf(pFile,"%s \n", text.c_str());
      fclose (pFile);
      return;
    }
  }
}


FileLogDevice::~FileLogDevice(void)
{
}
