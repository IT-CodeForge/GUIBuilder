#include "handle64bit.h"

int p64toi(void* p)
{
  unsigned long long int ip = (unsigned long long int)p;
  int i = ip;
  return i>0 ? i : -i;
}