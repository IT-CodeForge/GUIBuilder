#include "UStringListe.h"
#include "UVectorElement.h"

UStringListe::UStringListe()
  :UVector()
{
}

UStringListe::UStringListe(UStringListe& s)
{
  if(&s == this) return;

  rewind();

  while( ( aktE = s.getNext() ) !=  0 )
  {
    push_back(*getContent(aktE));
  }
}

UStringListe& UStringListe::operator=(UStringListe & s)
{
  if(&s == this) return *this;

  s.rewind();

  while( (aktE = s.getNext()) !=  0 )
  {
    push_back(*getContent(aktE));
  }

  return *this;
}

UStringListe::~UStringListe()
{
  deleteAllContentOfElements();

  // hier wird Basisklasse zerst�rt
}

void UStringListe::deleteContentOfElement(UVectorElement* referingElement)
{
  delete ((UString*)referingElement->content);
  referingElement->content = 0;
}

UString UStringListe::toString(UString left, UString mid, UString right)
{
  UString result;
  for(int i=0; i<size; i++)
  {
    if(i==0) result = left;
    result = result + getAt(i) + right;
    if(i<size-1) result = result + mid + left;
  }

  return result;
}

void UStringListe::setAt(int pos, UString s)
{
  if(pos>=size)
  {
     while( UVector::push_back(new UString) < pos );
     *((UString*)UVector::getLast()->content) = s;
  }
  else
  {
    *((UString*)UVector::getAt(pos)->content) = s;
  }
}

int UStringListe::insertAt(int pos, UString s)
{
  if(pos == size)
  {
    UVector::push_back(new UString(s));
  }
  else if(pos >= size)
  {
    for(int i=size; i<pos; i++)
    {
      UVector::push_back(new UString());
    }
    UVector::push_back(new UString(s));
  }
  else
  {
    UString* ps = new UString(s);
    UVector::insertAt(pos, ps);
  }

  return size;
}

UString UStringListe::getAt(int pos)
{
  return *getContent(UVector::getAt(pos));
}

int UStringListe::push_back(UString s)
{
  return UVector::push_back(new UString(s));
}

int UStringListe::find(UString compare, int startpos)
{
  if(startpos >= size) return -1;

  for (int i=startpos; i<size; i++)
  {
    if( getAt(i) == compare )
    return i;
  }

  return -1;
}

UStringListe& UStringListe::setToFragments(UString theString, UString separator)
{
  clear();

  if(separator == "")
  {
     this->push_back(theString);
     return (*this);
  }

  if(theString == "")
  {
     this->push_back("");
     return (*this);
  }

  int pos = 0;                 // "abc, def"    Length()=8    Pos(",") = 3
  while (pos > -1)               //  01234567
  { 
    //  012 = SubString(0,3)
    pos = theString.find(separator);

    if (pos == -1) // zerlegung ist zu Ende
    {
      push_back(theString);
    }
    else
    {
      UString teilVorTrennzeichenfolge  = theString.subString(0,pos);
      UString teilNachTrennzeichenfolge = theString.subString(pos+separator.length(), -1); // -1 = bis zum Ende
      push_back( teilVorTrennzeichenfolge );
      theString = teilNachTrennzeichenfolge;
    }
  }

  return (*this);
}

const UString* UStringListe::getContent(UVectorElement* element)
{
  if(element==0) return &emptyString;

  return (UString*)element->content;
}

