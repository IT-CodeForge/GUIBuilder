#ifndef _UStringListe_h_
#define _UStringListe_h_

#include "UString.h"
#include "UVector.h"

class UStringListe : public UVector
{
protected:
  void deleteContentOfElement(UVectorElement* referingElement);
  const UString* getContent(UVectorElement* element);
  UString emptyString;

public:
  UStringListe();
  UStringListe(UStringListe& s);
  UStringListe& operator=(UStringListe & s);
  UStringListe& copyFrom(UStringListe & s){*this=s; return *this;};
  virtual ~UStringListe();

  UString toString(UString left="[", UString mid=" ", UString right="]"); //[aaa] [bbb] [ccc]

  int push_back(UString s); // Returns size

  void setAt(int pos, UString s); //Fills in elements bevore, if necessary
                                  // Element an Stelle i wird �berschrieben,
                                  // Wenn i > size(), dann
                                  // wird mit Leerstrings aufgef�llt. Wenn
                                  // i = size(), dann wird ein pushBack(..)
                                   // ausgef�hrt.

  int insertAt(int pos, UString s); // An stelle von i, der Rest wird nach
                                        // rechts ger�ckt. Wenn i > size(), dann
                                        // wird mit Leerstrings aufgef�llt. Wenn
                                        // i = size(), dann wird ein pushBack(..)
                                        // ausgef�hrt.
                                        // Returns size
  UString getAt(int pos);         // inhalt an Index 0 .. size()-1.  Wenn
                                  // i >= size() liefert der Befehl einen
                                  // Leerstring

  UString operator[](int pos){return getAt(pos);};

  UStringListe& setToFragments(UString theString, UString separator);
  int find(UString compare, int startpos=0); // Returns position with compare or -1
};

#endif



