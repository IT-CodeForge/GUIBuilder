#ifndef _UStringListe2DExt_h_
#define _UStringListe2DExt_h_
/*
Erweiterte Funktionalit�t zur UStringListe2D. Speicherhandling ist in dieser
Klasse nicht erlaubt. Hierf�r ist ausschliesslich die Basisklasse
UStringListe2D zust�ndig. Speicherver�ndernde Elemente sind dort private.
*/

#include "UStringListe2D.h"

class UStringListe2DExt : public UStringListe2D
{
public:
  UStringListe2DExt():UStringListe2D(){};
  UStringListe2DExt(UStringListe2DExt & kopierkonstruktor){throw "Copy not allowed";};
  UStringListe2DExt& operator=(const UStringListe2DExt & s){throw "Copy not allowed";};

  void swapCol(int x1, int x2);// Tauscht zwei Spalten

  void copyRowToRow(int sourceY, int targetY, int firstX=-1, int lastX=-1);
  //Kopiert Zeile sourceY in
  // Zeile targetY. Zeile targetY wird
  // vollst�ndig �berschrieben. Falls sourceY oder
  // targetY nicht existieren wird die Methode
  // abgebrochen. Es �ndert sich dann nichts.
  // Nur Spalte firstX bis lastX. -1 bedeutet
  // erste / letzte Spalte.

  void copyColToCol(int sourceX, int targetX, int firstY=-1, int lastY=-1);
  // Kopiert Spalte sourceX in
  // Spalte targetX. Spalte targetX wird
  // vollst�ndig �berschrieben. Falls sourceX oder
  // targetX nicht existieren wird die Methode
  // abgebrochen. Es �ndert sich dann nichts.
  // Nur Zeile firstY bis lastY. -1 bedeutet
  // erste / letzte Zeile.

  bool isRowEmpty(int y, bool trimBevore);   // Liefert true, wenn alle
  // Elemente Leerstringe sind. Ist trimBevore=true,
  // dann wird die Zeile zuerst getrimmt.

  bool isColEmpty(int x, bool trimBevore);   // Liefert true, wenn alle
  // Elemente Leerstringe sind. Ist trimBevore=true,
  // dann wird die Spalte zuerst getrimmt.
  // �berschriften werden niemals ber�cksichtigt

  void trimElementsInRow(int y);// L�scht alle Leerstrings aus den Zeilenfeldern.
  // F�hrt auf jedes Feld selbst ein trim() durch
  // --> F�hrende und abschliessende Leerzeichen
  // werden entfernt

  int countElementsInRow(int y);//Z�hlt alle Zeilenfelder die kein Leerstring sind.

  void trimElementsInCol(int x);//L�scht alle Leerstrings aus den Spaltenfeldern.
  // F�hrt auf jedes Feld selbst ein trim() durch
  // --> F�hrende und abschliessende Leerzeichen
  // werden entfernt
  // �berschriften werden niemals ber�cksichtigt

  int countElementsInCol(int x);//Z�hlt alle Spaltenfelder die kein Leerstring sind.

  void trimElements();         // L�scht alle Leerstrings aus den Feldern der
  // gesamten Liste. F�hrt auf jedes Feld selbst
  // ein trim() durch --> F�hrende und
  // abschliessende Leerzeichen werden entfernt
  // �berschriften werden niemals ber�cksichtigt

  int getAtInt(int x, int y, bool* isValid = 0); // Liefert 0, wenn
  // Inhalt keine Zahl ist, isValid wird dann
  // false, sofern ein Zeiger daf�r �bergeben
  // wurde.

  /*  // In Calendar-Klasse ausgelagert!
     int getAtDDMMYYYY(int x, int y, bool* isValid = 0); // Liefert bei Fehler 0
                                  // wenns Klappt: die Tage seit 1.Jan.2000
                                  // 3.06.2013  ist erlaubt.
                                  // Schalttage sind noch unber�cksichtigt :(

     void setAtDDMMYYYY(int x, int y, int day); // 32 --> 1.2.2000;
  */

  void setAtDouble(int x, int y, double w, int nachkommastellen);

  double getAtDouble(int x, int y, bool* isValid = 0); // Liefert 0, wenn
  // Inhalt keine Zahl ist, isValid wird dann
  // false, sofern ein Zeiger daf�r �bergeben
  // wurde.

  int searchRelatedY(int x, UString searchString, int startY=0); //Durchsucht
  // Spalte x ab Zeile startY (einschliesslich)
  // nach erstem Treffer von searchString. Liefert
  // entsprechenden Zeilenindex. Wenn keine
  // Treffer: return -1

  int searchRelatedX(int y, UString searchString, int startX=0); //Durchsucht
  // Zeile y ab Spalte startX (einschliesslich)
  // nach erstem Treffer von searchString. Liefert
  // entsprechenden Spaltenindex. Wenn keine
  // Treffer: return -1

  // Collumn = Spate
  // Gesamte Tabelle nach dem Inhalt der Spalte[x] sortieren. (SwapRow wird verwendet)
  void sortCol(int y, bool numericNotAnsi, int firstX=0, int lastX=-1, bool aufsteigend=true);

  // Row = Zeile
  // Gesamte Tabelle nach dem Inhalt der Zeile[y] sortieren. (SwapCol wird verwendet)
  void sortRow(int x, bool numericNotAnsi, int firstY=0, int lastY=-1, bool aufsteigend=true);

  // Kopiert die Quelldaten in diese Tabelle
  void init(UStringListe2D* quellDaten);

  // Schreibt die Tabelle in eine Datei. Separatoren d�rfen nur ein Zeichen haben!
  void writeToFile (UString filename, UString itemSeparator = ";", UString lineSeparator = "\n");

  // Liest die Tabelle aus einer Datei. Separatoren d�rfen nur ein Zeichen haben!
  bool readFromFile(UString filename, UString itemSeparator = ";", UString lineSeparator = "\n", unsigned char* ignoreList = (unsigned char*)"\r", int ignoreListSize = 1);
};

#endif

