#ifndef _Log_h_
#define _Log_h_

#include "UString.h"
#include "LogFlags.h"

#define S_ UString()   // Um einen Text mit TG-String zu beginnen: out(S_ + "Hallo" + "Du")
// Markierungen: E: X: M: ... Enter Exit Markieren

#define IFLOG if((Log::enableLog)&&(Log::getLogDevice()>0))

class LogDevice;
class Log
{
private:
  static int          mSubLevel;
  static LogDevice*   mMyLogDevice;
  static bool         mUseProcessID;
  static unsigned int mFlags;

  static UString     getSubLevelString();

public:
  static const int  USE_PROCESSID = true;

  static bool       enableLog;
  static void       setFlags(unsigned int flags);
  static void       out (UString logText, void* currentObjectAddress = 0, unsigned int flags = LF_D);
  static void       setLogDevice(LogDevice* dev, bool useProcessID = false); // Ist LogDevice == 0 dann wird kein out(..)-Kommando verarbeitet.
  static LogDevice* getLogDevice(){return mMyLogDevice;};
};

#endif
