#ifndef _handle64bit_h_
#define _handle64bit_h_

int p64toi(void* p);

#endif