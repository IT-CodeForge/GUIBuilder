#include "Log.h"
#include "LogDevice.h"
#include "SystemAPI.h"

// Statische Klassenvariablen ins Leben rufen:
int          Log::mSubLevel;     // Alle statischen Variablen existieren in den
LogDevice*   Log::mMyLogDevice = 0;    // Objekt-Destruktoren nicht mehr!
bool         Log::mUseProcessID = false;
unsigned int Log::mFlags = LF_D;
bool         Log::enableLog = true;

void Log::out(UString logText, void* currentObjectAddress, unsigned int flags)
{
  if (mMyLogDevice     == 0) return;
  if ((flags & mFlags) == 0) return;

  logText = logText + "\n";

  UString objAddress;
  if (currentObjectAddress != 0)
  {
    objAddress = S_ + "(" + UString().addPointer(currentObjectAddress) + ")  ";
  }

  UString pid;
  if (mUseProcessID)
  {
    pid = pid + "000000" + SystemAPI::threadGetCurrentID();
    pid = pid.trimLength(6, ' ', true); // Auf laenge 6 von rechts her
    pid = S_ + "[" + pid + "]  ";
  }

  UString subLevelString = getSubLevelString();
  if(logText.subString(0, 2)=="E:")                 // enter
  {
    logText = subLevelString + logText;
    mSubLevel ++;   // DANACH (!!) wird erst einger�ckt!
  }
  else if(logText.subString(0,2)=="X:")            // exit
  {
    mSubLevel --;
    if (mSubLevel < 0) mSubLevel = 0;
    subLevelString = getSubLevelString();
    logText = subLevelString + logText;
  }
  else if(logText.subString(0,2)=="M:")            // mark
  {
    UString s;
    s  = subLevelString + ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n";
    int start=2;
    if(logText[start]==' ') start=3;
    s += pid + objAddress + subLevelString + logText.subString(start);
    s += pid + objAddress + subLevelString + ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n";
    logText = s;
  }
  else                                             // nur loggen
  {
    logText = subLevelString + logText;
  }

  logText = pid + objAddress + logText;

  mMyLogDevice->out(logText);
}

void Log::setFlags(unsigned int flags)
{
  mFlags = flags;
}

void Log::setLogDevice(LogDevice* logDevice, bool useProcessID)
{
  Log::mUseProcessID = useProcessID;

  if ((mMyLogDevice == 0)&&(logDevice != 0)) // Erstinitialisierung?
  {
    mSubLevel = 0;
  }

  mMyLogDevice = logDevice;
}

UString Log::getSubLevelString()
{
  UString erg;
  for(int i=0; i < mSubLevel; i++)
  {
    erg = erg + ".  ";
  }
  return erg;
}

