#include "UStringListe2D.h"

#include "UStringListe.h"

#include <vector>
using std::vector;

// Es werden String* gespeichert. diese werden hier mit new angelegt und
// ggfalls auch wieder gel�scht.
#define VECTORDATATYPE   UStringListe*
#define VECTORCLASSNAME  vector<VECTORDATATYPE>
#define DIE_VEKTORLISTE  ((VECTORCLASSNAME*)dieVectorListe)

void UStringListe2D::copyFrom(UStringListe2D & s)
{
  for(int y = 0; y<s._height; y++)
  {
    this->insertRow(_height, s.at(y));  // Handelt _width nicht
  }

  _width = s._width;
}

UStringListe2D::UStringListe2D()
{
  _width  = 0;
  _height = 0;
  dieVectorListe = new VECTORCLASSNAME();
}

UStringListe2D::~UStringListe2D()
{
  clear();
  delete DIE_VEKTORLISTE;
}

void UStringListe2D::clear()
{
  for (int i=0; i<height(); i++)
  {
    VECTORDATATYPE stringListe = DIE_VEKTORLISTE->at(i);
    delete stringListe;
  }

  DIE_VEKTORLISTE->clear();

  _width  = 0;
  _height = 0;
}

VECTORDATATYPE UStringListe2D::createNewLine()
{
  VECTORDATATYPE neueZeile = new UStringListe();
  if (_width-1 > 0)
  {
    neueZeile->setAt(_width-1,"");
  }
  return neueZeile;
}

void UStringListe2D::insertRow(int y, UStringListe* s)
{
  if(y<0)return;

  VECTORDATATYPE pNewLine;
  int delta = y - _height;

  // Fehlende Zeilen am Ende anh�ngen: _height l��ft immer mit und zeigt immer aufs Ende
  if (delta > 0)
  {
    for (int k=0; k<delta; k++)
    {
      pNewLine = createNewLine();
      DIE_VEKTORLISTE->insert(DIE_VEKTORLISTE->begin()+_height, pNewLine);
      _height++;
    }
  }

  // Diese Zeile mitten rein.
  pNewLine = createNewLine();
  if(s!=0)
  {
    pNewLine->copyFrom( *s );
  }
  DIE_VEKTORLISTE->insert(DIE_VEKTORLISTE->begin()+y, pNewLine);
  _height++;

  // WSenn die neue Zeile gr�sser ist als _width, dann muss das
  // Problem ausserhalb dieser Methode gehandelt werden.
}

void UStringListe2D::insertCol(int x)
{
  if(x<0)return;

  // Mindestens eine Reihe muss da sein!
  if (_height == 0)
  {
    insertRow(0);
  }

  // �ber alle Zeilen laufen
  for (int y=0; y<_height; y++)
  {
    at(y)->insertAt(x, ""); // dieser Befehlt f�llt Leerelemente ein, falls n�tig
  }

  _width = at(0)->getSize(); //Nachgucken wieviel eigentlich eingef�llt wurden.
}

VECTORDATATYPE UStringListe2D::at(int y)
{
  if(y<0)return 0;

  if (y<_height)
  {
    VECTORDATATYPE res = DIE_VEKTORLISTE->at(y);
    return res;
  }
  else
  {
    return 0;
  }
}

void UStringListe2D::setAt(int x, int y, UString r)
{
  if((x<0)||(y<0))return;

  if (y >= _height)
  {
    insertRow(y);
  }

  if (x >= _width)
  {
    insertCol(x);
  }

  at(y)->setAt(x, r);
}

UString UStringListe2D::getAt(int x, int y )
{
  if((x<0)||(y<0))return "";

  if ((x<_width)&&(y<_height))
  {
    return at(y)->getAt(x);
  }
  else
  {
    return "";
  }
}

void UStringListe2D::deleteRow(int y)
{
  if(y<0) return;

  if (y >= _height) return;

  // Element aus Speicher l�schen
  delete at(y);

  // Element aus Liste l�schen
  DIE_VEKTORLISTE->erase( DIE_VEKTORLISTE->begin()+y );

  _height = DIE_VEKTORLISTE->size();
}

void UStringListe2D::deleteCol(int x)
{
  if(x<0)return;

  // Mindestens eine Reihe muss da sein!
  if (_height == 0)
  {
    return;
  }

  for (int k=0; k<_height; k++)
  {
    at(k)->erase(x);
  }

  _width = at(0)->getSize();
}

void UStringListe2D::swapRow(int y1, int y2)
{
  if((y1<0)||(y2<0))return;

  if ((y1>=_height)||(y2>=_height)) return;

  VECTORDATATYPE row_merk      = DIE_VEKTORLISTE->begin()[y1];
  DIE_VEKTORLISTE->begin()[y1] = DIE_VEKTORLISTE->begin()[y2];
  DIE_VEKTORLISTE->begin()[y2] = row_merk;
}

UString UStringListe2D::toString()
{
  UString s;
  UString zeile;
  for (int i=0; i<height(); i++)
  {
    at(i)->toString();

    /*    DEBUG
          if (zeile.length()==0)
          {
             int a=8; a=a*a;
          }

          if (i%500==0)
          {
             int a=8; a=a*a;
          }

          s = s + zeile;
          if (i < height()-1)
          {
             s = s + "\n";
          }
    */

    zeile = at(i)->toString();
    s.addText( zeile );
    if (i < height()-1)
    {
      s.addText("\n", 1);
    }

  }
  return s;
}

