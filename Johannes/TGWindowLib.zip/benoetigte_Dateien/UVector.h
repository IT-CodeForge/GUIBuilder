#ifndef _UVector_h_
#define _UVector_h_

#include "UString.h"

class UVectorElement;
class UVector
{
protected:
  UVectorElement* first;
  UVectorElement* last;
  int             size;

  UVectorElement* aktE;

  //virtual void deleteContentOfElement(UVectorElement* referingElement){};  // DEBUG: MUST be abstract!
  virtual void deleteContentOfElement(UVectorElement* referingElement)=0; 

  UVector(UVector & notAllowed);
  UVector& operator= (UVector & notAllowed);

public:
  UVector();
  virtual ~UVector();
  void deleteAllContentOfElements();
  UString toString();
  int insertAt(int pos, void* content); // Returns size  or -1 if pos >= size
  int push_back(void* content); // Returns new size
  int getSize(){return size;};
  UVectorElement* getAt(int pos); // Returns 0 if not existing
  UVectorElement* getLast(){return last;};
  int erase(int pos);     // Rest wird nach links einger�ckt. Wenn
                          // i >= size() wird der Befehl ignoriert.
  void rewind(){aktE = first;}; // Set element pointer to the first element
  UVectorElement* getNext();
  void clear();    // Gesamte Listeninhalte l�schen. size()
                   // ist danach 0.
};

#endif