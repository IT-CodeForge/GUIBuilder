#ifndef _TGW_AllClassDeclarations_h_
#define _TGW_AllClassDeclarations_h_

// #include "TGW_AllClassDeclarations.h"

class TGWBitmap;
class TGWBitmapWindow;
class TGWButton;
class TGWindow;
class TGWCanvas;
class TGWCheckBox;
class TGWEdit;
class TGWMainWindow;
class TGWTimer;
class TGWTrackBar;

#endif