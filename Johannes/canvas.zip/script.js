var canvas;
var ctx

function draw_line(x1, y1, x2, y2, fillstyle = "hsl(0deg, 100%, 0%)")
{
    ctx.moveTo(x1 + 0.5, y1 + 0.5);
    ctx.lineTo(x2 + 0.5, y2 + 0.5);
    ctx.lineWidth = 1;
    ctx.strokeStyle = fillstyle;
    ctx.stroke();
}

window.onload = function () {
    canvas = document.getElementById("CursorLayer");
    ctx = canvas.getContext("2d");
    draw_line(5, 0, 5, 100)
}